package dog;

	public interface Dog {

		public String getOwnerName();

		public String getDogName();

		public String getBark();
	}

