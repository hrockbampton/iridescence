package dog;

public class OliverDogRunner {
	
	public static void main(String[] args) {
		
		OliverDog myDog = new OliverDog("Oliver", "Amelia", "Woof");
		System.out.println(myDog);

	
	}
}
