package output;

public class Poem {

		
public static void main(String [] args) {
		
		System.out.println("Roses are red, violets are blue, I am tired, how about you?");
}

}
