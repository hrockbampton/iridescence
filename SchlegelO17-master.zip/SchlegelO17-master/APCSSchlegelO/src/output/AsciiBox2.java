package output;

public class AsciiBox2 {
	
	
	public static void main(String[] args)
	{
		System.out.println("name \t  date \n\n" );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++                   +++ " );
		System.out.println("+++                   +++ " );
		System.out.println("+++                   +++ " );
		System.out.println("+++                   +++ " );
		System.out.println("+++     CompSci       +++ " );
		System.out.println("+++                   +++ " );
		System.out.println("+++                   +++ " );
		System.out.println("+++                   +++ " );
		System.out.println("+++                   +++ " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("+++++++++++++++++++++++++ " );
	}
}
