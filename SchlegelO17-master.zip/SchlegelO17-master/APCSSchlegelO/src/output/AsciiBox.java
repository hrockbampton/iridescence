package output;

public class AsciiBox {

	public static void main(String[] args)
	{
		System.out.println("Oliver Schlegel \t  9/15/17 \n\n" );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAA " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
		System.out.println("+++++++++++++++++++++++++ " );
	}
}