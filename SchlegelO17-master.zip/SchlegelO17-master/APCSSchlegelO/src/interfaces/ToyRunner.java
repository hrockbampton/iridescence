package interfaces;

	import static java.lang.System.*;

	public class ToyRunner
	{
		public static void main(String[] args)
		{
		}
	}
	
