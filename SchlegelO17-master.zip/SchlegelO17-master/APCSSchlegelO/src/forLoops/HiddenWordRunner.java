package forLoops;

public class HiddenWordRunner {

}
