package inheritance;

public class DisneyShip {

}
