package inheritance;

import java.util.ArrayList;

public class ShipDemo {

	public static void main(String args[])
	{
		
		ArrayList ships = new <Ship> ArrayList();
		
		ships.add()
		
		CruiseShip titanic = new CruiseShip("Titanic", "1909", 3547 );
		
		System.out.println(titanic.toString());
		
		
		
		
		
		
		
		
		
	}
	
	
	
}
