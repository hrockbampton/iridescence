# SchlegelO17
#spaceGame
the purpose of the game was to entertain
the game involves controlling a ship and using its wepons to destroy the enemy ships. 
The ship is controlled using the WASD keys and fires using the space bar. the goal is to survive
as long as you can and get a high score.

### I felt one of the hardest part of my code was getting the ship to move diagonally as well as move and shoot at the same time. 
Getting the ship to fire was the most difficult of all my code.

### most interesting code

public Laser(float x, float y)
  {
    shipPos = new PVector(x,y);
    speed = new PVector(0,5);
  }
  
  void display()
  {
    fill(150,0,0);
    rect(shipPos.x,shipPos.y,5,25,5);
    shipPos.sub(speed);
        
  } 
  
}

//in runner---------------------------------------------------

 ArrayList<Laser> lasers = new ArrayList<Laser>();
 
  for(Laser blast : lasers)
      blast.display();
 
  void keyReleased(){
    if(key=='w'){
      wKey=0;
    }
    if(key=='a'){
      aKey=0;
    }
    if(key=='s'){
      sKey=0;
    }
    if(key=='d'){
      dKey=0;
    }
    if(key == ' '){
      shoot();
    }
  }
  
  
   void shoot()
  {
    lasers.add(new Laser(ship.shipX() + 17.5, ship.shipY() - 85));
  }
  ////
  shoots lasers when space bar is pressed
  
  
  ##Built with
  processing
  
  
  ##Author
  
  *Oliver Schlegel
  
  ## Acknowledgments
  thanks to sam erickson-schultz for helping with WASD
  
